=====================
CONTENTS OF THIS FILE
=====================

* Steps for Importing GWDB Downloads to MS Access
* Steps for Importing GWDB Downloads to MS Excel

============================================
STEPS FOR IMPORTING GWDB DOWNLOADS TO ACCESS
============================================

NOTE: Instructions are based on MS Access 2016. The steps may vary slightly for 
      older or newer versions.

1.  Open a new or existing Access Database.
2.  Click on the �External Data� Tab.
3.  Select �Text File� from the �Import & Link� Group.
4.  Browse to the Source Data File and then click �Open�.
5.  Check �Import the source data into a new table in the current database.�
6.  Click �OK�.
7.  Select �Delimited� from the "Import Text Wizard" diaglog box and click
    �Next�.
8.  Select "Other" in the �Choose the delimiter that separates your fields:� box 
    and enter the pipe symbol �|� ("Shift" and �\� keys) in the box provided.
9.  Check the box that says, �First Row Contains Field Names�.
10. Make sure "Text Qualifier" is �{none}� and click �Next�.
11. For all files except those listed in the table below no changes need to be 
    made in this step, simply click "Next" and go to Step 12 below.

    The files listed in the table below will need to have the data type changed
    to Short Text or Long Text for the columns listed in the table. For more 
    information on how to do this follow the steps listed below the table.

    +-----------------------------+----------------+----------------+
    |FILE                         |Short/Long Text |Date/Time       |
    +-----------------------------+----------------+----------------+
    |WaterQualityMajor            |SampleTime      |SampleDate      |
    |                             |Reliability     |                |
    +-----------------------------+----------------+----------------+
    |WaterQualityMinor            |SampleTime      |SampleDate      |
    |                             |Reliability     |                |
    +-----------------------------+----------------+----------------+
    |WaterQualityCombination      |SampleTime      |SampleDate      |
    |                             |Reliability     |                |
    +-----------------------------+----------------+----------------+
    |WaterQualityOtherUnassigned  |SampleTime      |SampleDate      |
    |                             |Reliability     |                |
    +-----------------------------+----------------+----------------+
    |WaterLevelsMajor             |                |MeasurementDate |
    +-----------------------------+----------------+----------------+
    |WaterLevelsMinor             |                |MeasurementDate |
    +-----------------------------+----------------+----------------+
    |WaterLevelsCombination       |                |MeasurementDate |
    +-----------------------------+----------------+----------------+
    |WaterLevelsOtherUnassigned   |                |MeasurementDate |
    +-----------------------------+----------------+----------------+
    |WellTests                    |                |WellTestDate    |
    +------------ ----------------+----------------+----------------+
    

    To change a column data type to Short Text or Long Text:
    ---------------------------------------------
    A. Click on the column heading for the appropriate field.
    B. Choose "Shor Text" or "Long Text" from the "Data Type" dropdown box.
    C. Click "Next".
    D. If no columns need to be changed to a date format, proceed to Step 12,
       otherwise, follow the steps below to change the format of a date field. 

    To change a column data type to Date/Time:
    ------------------------------------------
    A. Click on the column heading for the appropriate field.
    B. Make sure that "Date/Time" is displayed in the "Data Type" dropdown box.
    C. Click on the "Advanced" button.
    D. Select "YMD" from the "Date Order:" dropdown box.
    E. Change the "Date Delimiter:" field to "-".
    F. Click "OK".
       Note: Steps C thru F only have to be done once and it will change the 
             settings for all the Date/Time fields in the table.
    D. Click "Next".
    E. Proceed to Step 12.   
        
12. Select �No primary key� and then click "Next".
13. Assign a name for your table in the �Import to Table:� box and click "Finish".

Note: An "ImportErrors" table may be generated for fields containing null values.
      However, all data should still have been imported correctly. To make an
      Access field accept null values, set "Required" field property to "No" and 
      make sure the "ValidationRule" property setting doesn't prevent null values.

Note: WaterQualityMajor file is a very large file (over 2 million records)
      and may need to be imported into its own separate Access Database. If the
      following error message is displayed, you may need to "Compact & Repair" the
      database: "Cannot open database.It may  not be a database that your
      application recognizes, or the file may be corrupt."


==========================================
STEPS FOR IMPORTING SDR DOWNLOADS TO EXCEL
==========================================

Instructions are based on MS Excel 2016. The steps may vary slightly for older
or newer versions.

---------------------------------------------------------------------------
NOTE: WaterQualityMinor file is too large (exceeds Excel's row 
      limit) and cannot be imported using Excel's Import Wizard. For best 
      results export smaller groups of data through SDR Reports, or import 
      into an MS Access table. 
---------------------------------------------------------------------------

1.  In a blank Excel file, click on the �Data� toolbar.
2.  Select �From Text� from the �Get External Data� section.
3.  Locate the downloaded files, select desired file, and then click �Import�.
    
    **This will bring up the Text Import Wizard box.**

    -------------------------------
    Text Import Wizard Step 1 of 3:
    -------------------------------

     A. Select �Delimited� for the "Original Data Type" in the "Text Import Wizard
        -Step 1 of 3" dialog box.
     B. Check the "My Data has headers." box.
     C. Click �Next�.

    -------------------------------
    Text Import Wizard Step 2 of 3:
    -------------------------------

     A. Uncheck the �Tab� box in the "Delimiters" section of the "Text Import Wizard
        -Step 2 of 3" dialog box.
     B. Check �Other�.
     C. Enter the pipe �|� symbol ("Shift" and the �\� key) in the box provided.
     D. Select �{none}� for �Text qualifier�.
     E. Click �Next�.

    -------------------------------
    Text Import Wizard Step 3 of 3:
    -------------------------------

    In this step you will need to change the "StateWellNumber" and "StoretCode" fields 
    to a "Text" field."StoretCode" will only be found in Water Quality downloads.

   
    To change a column data type:
    ------------------------------
    A. Click on the column heading for the appropriate field in the "Text Import 
       Wizard - Step 3 of 3" dialog box.
    B. Choose the appropriate format (Text) in the "Column Data Format" box.
    C. Click "Finish".    
        
4.  Click �OK� in the �Import Data� box.